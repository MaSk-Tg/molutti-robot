import logging
from pyrogram.errors import InputUserDeactivated, UserNotParticipant, FloodWait, UserIsBlocked, PeerIdInvalid
from info import AUTH_CHANNEL, LONG_IMDB_DESCRIPTION, MAX_LIST_ELM
from imdb import IMDb
import asyncio
from pyrogram.types import Message, InlineKeyboardButton
from pyrogram import enums
from typing import Union
import re
import os
from datetime import datetime
from typing import List
from database.users_chats_db import db
from bs4 import BeautifulSoup
import requests

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

BTN_URL_REGEX = re.compile(
    r"(\[([^\[]+?)\]\((buttonurl|buttonalert):(?:/{0,2})(.+?)(:same)?\))"
)

imdb = IMDb() 

BANNED = {}
SMART_OPEN = '“'
SMART_CLOSE = '”'
START_CHAR = ('\'', '"', SMART_OPEN)

# temp db for banned 
class temp(object):
    BANNED_USERS = []
    BANNED_CHATS = []
    ME = None
    CURRENT=int(os.environ.get("SKIP", 2))
    CANCEL = False
    MELCOW = {}
    U_NAME = None
    B_NAME = None
    SETTINGS = {}

async def is_subscribed(bot, query):
    try:
        user = await bot.get_chat_member(AUTH_CHANNEL, query.from_user.id)
    except UserNotParticipant:
        pass
    except Exception as e:
        logger.exception(e)
    else:
        if user.status != 'kicked':
            return True

    return False


async def get_poster(query, bulk=False, id=False, file=None):
    if not id:
        # https://t.me/GetTGLink/4183
        query = (query.strip()).lower()
        title = query
        year = re.findall(r'[1-2]\d{3}$', query, re.IGNORECASE)
        if year:
            year = list_to_str(year[:1])
            title = (query.replace(year, "")).strip()
        elif file is not None:
            year = re.findall(r'[1-2]\d{3}', file, re.IGNORECASE)
            if year:
                year = list_to_str(year[:1]) 
        else:
            year = None
        movieid = imdb.search_movie(title.lower(), results=10)
        if not movieid:
            return None
        if year:
            filtered=list(filter(lambda k: str(k.get('year')) == str(year), movieid))
            if not filtered:
                filtered = movieid
        else:
            filtered = movieid
        movieid=list(filter(lambda k: k.get('kind') in ['movie', 'tv series'], filtered))
        if not movieid:
            movieid = filtered
        if bulk:
            return movieid
        movieid = movieid[0].movieID
    else:
        movieid = query
    movie = imdb.get_movie(movieid)
    if movie.get("original air date"):
        date = movie["original air date"]
    elif movie.get("year"):
        date = movie.get("year")
    else:
        date = "N/A"
    plot = ""
    if not LONG_IMDB_DESCRIPTION:
        plot = movie.get('plot')
        if plot and len(plot) > 0:
            plot = plot[0]
    else:
        plot = movie.get('plot outline')
    if plot and len(plot) > 800:
        plot = plot[0:800] + "..."

    return {
        'title': movie.get('title'),
        'votes': movie.get('votes'),
        "aka": list_to_str(movie.get("akas")),
        "seasons": movie.get("number of seasons"),
        "box_office": movie.get('box office'),
        'localized_title': movie.get('localized title'),
        'kind': movie.get("kind"),
        "imdb_id": f"tt{movie.get('imdbID')}",
        "cast": list_to_str(movie.get("cast")),
        "runtime": list_to_str(movie.get("runtimes")),
        "countries": list_to_str(movie.get("countries")),
        "certificates": list_to_str(movie.get("certificates")),
        "languages": list_to_str(movie.get("languages")),
        "director": list_to_str(movie.get("director")),
        "writer":list_to_str(movie.get("writer")),
        "producer":list_to_str(movie.get("producer")),
        "composer":list_to_str(movie.get("composer")) ,
        "cinematographer":list_to_str(movie.get("cinematographer")),
        "music_team": list_to_str(movie.get("music department")),
        "distributors": list_to_str(movie.get("distributors")),
        'release_date': date,
        'year': movie.get('year'),
        'genres': list_to_str(movie.get("genres")),
        'poster': movie.get('full-size cover url'),
        'plot': plot,
        'rating': str(movie.get("rating")),
        'url':f'https://www.imdb.com/title/tt{movieid}'
    }
# https://github.com/odysseusmax/animated-lamp/blob/2ef4730eb2b5f0596ed6d03e7b05243d93e3415b/bot/utils/broadcast.py#L37

async def broadcast_messages(user_id, message):
    try:
        await message.copy(chat_id=user_id)
        return True, "Success"
    except FloodWait as e:
        await asyncio.sleep(e.x)
        return await broadcast_messages(user_id, message)
    except InputUserDeactivated:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id}-Removed from Database, since deleted account.")
        return False, "Deleted"
    except UserIsBlocked:
        logging.info(f"{user_id} -Blocked the bot.")
        return False, "Blocked"
    except PeerIdInvalid:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id} - PeerIdInvalid")
        return False, "Error"
    except Exception as e:
        return False, "Error"

async def search_gagala(text):
    usr_agent = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/61.0.3163.100 Safari/537.36'
        }
    text = text.replace(" ", '+')
    url = f'https://www.google.com/search?q={text}'
    response = requests.get(url, headers=usr_agent)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    titles = soup.find_all( 'h3' )
    return [title.getText() for title in titles]


async def get_settings(group_id):
    settings = temp.SETTINGS.get(group_id)
    if not settings:
        settings = await db.get_settings(group_id)
        temp.SETTINGS[group_id] = settings
    return settings
    
async def save_group_settings(group_id, key, value):
    current = await get_settings(group_id)
    current[key] = value
    temp.SETTINGS[group_id] = current
    await db.update_settings(group_id, current)
    
def get_size(size):
    """Get size in readable format"""

    units = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB"]
    size = float(size)
    i = 0
    while size >= 1024.0 and i < len(units):
        i += 1
        size /= 1024.0
    return "%.2f %s" % (size, units[i])

def split_list(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]  

def get_file_id(msg: Message):
    if msg.media:
        for message_type in (
            "photo",
            "animation",
            "audio",
            "document",
            "video",
            "video_note",
            "voice",
            "sticker"
        ):
            obj = getattr(msg, message_type)
            if obj:
                setattr(obj, "message_type", message_type)
                return obj

async def get_media_info(media, client=None):
    """
    Extract media information and cache actual video metadata.

    For Telegram Video objects, width/height/duration are read directly.
    For document files such as MKV, ffprobe is used when metadata is not
    already cached in MongoDB. The scanned values are cached in MongoDB so
    the same file is not downloaded/scanned again.
    """
    language = "Unknown"
    resolution = getattr(media, "resolution", None) or "Unknown"
    subtitles = "Unknown"
    duration = getattr(media, "duration", None) or "Unknown"

    file_name = getattr(media, "file_name", "") or ""
    caption = getattr(media, "caption", "") or ""
    text = f"{file_name} {caption}"

    # Telegram Video objects can already contain these values.
    width = getattr(media, "width", None)
    height = getattr(media, "height", None)
    video_duration = getattr(media, "duration", None)

    if resolution == "Unknown" and width and height:
        resolution = _format_resolution(width, height)

    # Do not treat cached duration as Telegram duration when it is a string.
    if video_duration and isinstance(video_duration, (int, float)):
        duration = _format_duration(video_duration)

    # For documents (especially MKV), scan the real file only when needed.
    if client and (resolution == "Unknown" or duration == "Unknown"):
        try:
            scanned_resolution, scanned_duration = await _probe_document_media(
                client, media
            )
            if resolution == "Unknown" and scanned_resolution:
                resolution = scanned_resolution
            if duration == "Unknown" and scanned_duration:
                duration = scanned_duration

            # Cache successful scan results. Import lazily to avoid a circular
            # import because database.ia_filterdb also imports database modules.
            if scanned_resolution or scanned_duration:
                try:
                    from database.ia_filterdb import update_media_metadata
                    await update_media_metadata(
                        getattr(media, "file_id", None),
                        scanned_resolution,
                        scanned_duration
                    )
                except Exception as cache_error:
                    logger.exception(
                        "Failed to cache media metadata: %s", cache_error
                    )
        except Exception as probe_error:
            logger.exception("Media metadata scan failed: %s", probe_error)

    # Filename/caption fallback for resolution.
    if resolution == "Unknown":
        resolution_match = re.search(
            r"(?<!\d)(\d{3,4})\s*[pP]\b|"
            r"(?<!\d)(\d{3,4})\s*[xX]\s*(\d{3,4})(?!\d)",
            text,
            re.IGNORECASE
        )
        if resolution_match:
            if resolution_match.group(1):
                resolution = f"{resolution_match.group(1)}p"
            else:
                resolution = _format_resolution(
                    int(resolution_match.group(2)),
                    int(resolution_match.group(3))
                )

    # Filename/caption fallback for duration.
    if duration == "Unknown":
        duration_match = re.search(
            r"(?:(\d+)\s*h(?:ours?|rs?)?\s*)?"
            r"(?:(\d+)\s*m(?:in(?:utes?)?|ins?)?\s*)?"
            r"(?:(\d+)\s*s(?:ec(?:onds?)?|ecs?)?)",
            text,
            re.IGNORECASE
        )
        if duration_match and any(duration_match.groups()):
            duration = _format_duration(
                int(duration_match.group(1) or 0) * 3600
                + int(duration_match.group(2) or 0) * 60
                + int(duration_match.group(3) or 0)
            )

    # Detect languages.
    langs = [
        "Tamil",
        "Telugu",
        "Hindi",
        "Malayalam",
        "Kannada",
        "English"
    ]

    found_langs = [
        lang for lang in langs
        if re.search(rf"\b{lang}\b", text, re.IGNORECASE)
    ]

    if found_langs:
        language = ", ".join(found_langs)

    # Detect subtitles.
    if re.search(
        r"\b(ESub|ESubs|English\s*Sub(?:title)?s?)\b",
        text,
        re.IGNORECASE
    ):
        subtitles = "English"

    return language, resolution, subtitles, duration


def _format_resolution(width, height):
    """Return a human-friendly resolution such as 1080p."""
    try:
        width = int(width)
        height = int(height)
    except (TypeError, ValueError):
        return "Unknown"

    # Use the larger dimension so portrait videos are handled sensibly.
    pixels = max(width, height)
    if pixels >= 3840:
        return "2160p"
    if pixels >= 2560:
        return "1440p"
    if pixels >= 1920:
        return "1080p"
    if pixels >= 1280:
        return "720p"
    if pixels >= 854:
        return "480p"
    if pixels >= 640:
        return "360p"
    return f"{height}p"


def _format_duration(total_seconds):
    """Return duration in HH:MM:SS format."""
    try:
        total_seconds = max(0, int(float(total_seconds)))
    except (TypeError, ValueError):
        return "Unknown"

    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


async def _probe_document_media(client, media):
    """Download a document temporarily and read video metadata with ffprobe."""
    import tempfile

    file_id = getattr(media, "file_id", None)
    if not file_id:
        return None, None

    temp_dir = tempfile.mkdtemp(prefix="media_probe_")
    temp_path = os.path.join(temp_dir, "media")

    try:
        downloaded = await client.download_media(
            file_id,
            file_name=temp_path
        )
        if not downloaded or not os.path.exists(downloaded):
            return None, None

        # One ffprobe call gets width, height and duration together.
        process = await asyncio.create_subprocess_exec(
            "ffprobe",
            "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height:format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            downloaded,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=180
        )

        if process.returncode != 0:
            logger.error(
                "ffprobe failed for %s: %s",
                file_id,
                stderr.decode(errors="ignore")[-1000:]
            )
            return None, None

        values = [line.strip() for line in stdout.decode(errors="ignore").splitlines() if line.strip()]

        resolution = None
        duration = None

        if len(values) >= 2:
            try:
                width = int(values[0])
                height = int(values[1])
                resolution = _format_resolution(width, height)
            except (TypeError, ValueError):
                pass

        if len(values) >= 3:
            try:
                duration = _format_duration(float(values[2]))
            except (TypeError, ValueError):
                pass

        return resolution, duration

    except asyncio.TimeoutError:
        logger.error("ffprobe timed out for %s", file_id)
        return None, None
    except Exception as error:
        logger.exception("Unable to probe media %s: %s", file_id, error)
        return None, None
    finally:
        try:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass

def extract_user(message: Message) -> Union[int, str]:
    """extracts the user from a message"""
    # https://github.com/SpEcHiDe/PyroGramBot/blob/f30e2cca12002121bad1982f68cd0ff9814ce027/pyrobot/helper_functions/extract_user.py#L7
    user_id = None
    user_first_name = None
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        user_first_name = message.reply_to_message.from_user.first_name

    elif len(message.command) > 1:
        if (
            len(message.entities) > 1 and
            message.entities[1].type == enums.MessageEntityType.TEXT_MENTION
        ):
           
            required_entity = message.entities[1]
            user_id = required_entity.user.id
            user_first_name = required_entity.user.first_name
        else:
            user_id = message.command[1]
            # don't want to make a request -_-
            user_first_name = user_id
        try:
            user_id = int(user_id)
        except ValueError:
            pass
    else:
        user_id = message.from_user.id
        user_first_name = message.from_user.first_name
    return (user_id, user_first_name)

def list_to_str(k):
    if not k:
        return "N/A"
    elif len(k) == 1:
        return str(k[0])
    elif MAX_LIST_ELM:
        k = k[:int(MAX_LIST_ELM)]
        return ' '.join(f'{elem}, ' for elem in k)
    else:
        return ' '.join(f'{elem}, ' for elem in k)

def last_online(from_user):
    time = ""
    if from_user.is_bot:
        time += "🤖 Bot :("
    elif from_user.status == enums.UserStatus.RECENTLY:
        time += "Recently"
    elif from_user.status == enums.UserStatus.LAST_WEEK:
        time += "Within the last week"
    elif from_user.status == enums.UserStatus.LAST_MONTH:
        time += "Within the last month"
    elif from_user.status == enums.UserStatus.LONG_AGO:
        time += "A long time ago :("
    elif from_user.status == enums.UserStatus.ONLINE:
        time += "Currently Online"
    elif from_user.status == enums.UserStatus.OFFLINE:
        time += from_user.last_online_date.strftime("%a, %d %b %Y, %H:%M:%S")
    return time


def split_quotes(text: str) -> List:
    if not any(text.startswith(char) for char in START_CHAR):
        return text.split(None, 1)
    counter = 1  # ignore first char -> is some kind of quote
    while counter < len(text):
        if text[counter] == "\\":
            counter += 1
        elif text[counter] == text[0] or (text[0] == SMART_OPEN and text[counter] == SMART_CLOSE):
            break
        counter += 1
    else:
        return text.split(None, 1)

    # 1 to avoid starting quote, and counter is exclusive so avoids ending
    key = remove_escapes(text[1:counter].strip())
    # index will be in range, or `else` would have been executed and returned
    rest = text[counter + 1:].strip()
    if not key:
        key = text[0] + text[0]
    return list(filter(None, [key, rest]))

def parser(text, keyword):
    if "buttonalert" in text:
        text = (text.replace("\n", "\\n").replace("\t", "\\t"))
    buttons = []
    note_data = ""
    prev = 0
    i = 0
    alerts = []
    for match in BTN_URL_REGEX.finditer(text):
        # Check if btnurl is escaped
        n_escapes = 0
        to_check = match.start(1) - 1
        while to_check > 0 and text[to_check] == "\\":
            n_escapes += 1
            to_check -= 1

        # if even, not escaped -> create button
        if n_escapes % 2 == 0:
            note_data += text[prev:match.start(1)]
            prev = match.end(1)
            if match.group(3) == "buttonalert":
                # create a thruple with button label, url, and newline status
                if bool(match.group(5)) and buttons:
                    buttons[-1].append(InlineKeyboardButton(
                        text=match.group(2),
                        callback_data=f"alertmessage:{i}:{keyword}"
                    ))
                else:
                    buttons.append([InlineKeyboardButton(
                        text=match.group(2),
                        callback_data=f"alertmessage:{i}:{keyword}"
                    )])
                i += 1
                alerts.append(match.group(4))
            elif bool(match.group(5)) and buttons:
                buttons[-1].append(InlineKeyboardButton(
                    text=match.group(2),
                    url=match.group(4).replace(" ", "")
                ))
            else:
                buttons.append([InlineKeyboardButton(
                    text=match.group(2),
                    url=match.group(4).replace(" ", "")
                )])

        else:
            note_data += text[prev:to_check]
            prev = match.start(1) - 1
    else:
        note_data += text[prev:]

    try:
        return note_data, buttons, alerts
    except:
        return note_data, buttons, None

def remove_escapes(text: str) -> str:
    res = ""
    is_escaped = False
    for counter in range(len(text)):
        if is_escaped:
            res += text[counter]
            is_escaped = False
        elif text[counter] == "\\":
            is_escaped = True
        else:
            res += text[counter]
    return res


def humanbytes(size):
    if not size:
        return ""
    power = 2**10
    n = 0
    Dic_powerN = {0: ' ', 1: 'Ki', 2: 'Mi', 3: 'Gi', 4: 'Ti'}
    while size > power:
        size /= power
        n += 1
    return str(round(size, 2)) + " " + Dic_powerN[n] + 'B'
